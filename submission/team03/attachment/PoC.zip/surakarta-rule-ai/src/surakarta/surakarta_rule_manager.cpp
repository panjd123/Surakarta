#include "surakarta_rule_manager.h"
#include <algorithm>
#include <iostream>

void SurakartaRuleManager::OnUpdateBoard() {
    // TODO:
    // Every time the board and game_info is updated to the next round version, this function will be called.
    // You don't need to implement this function if you don't need it.
    // A more delicate way is to use Qt's signal and slot mechanism, but that's the advanced part.
}

SurakartaIllegalMoveReason SurakartaRuleManager::JudgeMove(const SurakartaMove& move) {
    // TODO: Implement this function.

    // An example of how to get the color of a piece and the current player.
    for (unsigned int i = 0; i < board_size_; i++) {
        for (unsigned int j = 0; j < board_size_; j++) {
            PieceColor color = (*board_)[i][j]->GetColor();
            if (color == PieceColor::BLACK) {
                // i,j is the position of a black piece
            } else if (color == PieceColor::WHITE) {
                // i,j is the position of a white piece
            } else {
                // i,j is an empty position
            }
        }
    }
    SurakartaPlayer current_player = game_info_->current_player_;
    if (current_player == SurakartaPlayer::BLACK) {
        // black player's turn
    } else if (current_player == SurakartaPlayer::WHITE) {
        // white player's turn
    }

    return SurakartaIllegalMoveReason::LEGAL;
}

std::pair<SurakartaEndReason, SurakartaPlayer> SurakartaRuleManager::JudgeEnd(const SurakartaIllegalMoveReason reason) {
    // TODO: Implement this function.
    // Note that at this point, the board and game_info have not been updated yet.

    return std::make_pair(SurakartaEndReason::NONE, SurakartaPlayer::NONE);
}

std::unique_ptr<std::vector<SurakartaPosition>> SurakartaRuleManager::GetAllLegalTarget(const SurakartaPosition postion) {
    // TODO:
    // We don't test this function, you don't need to implement this function if you don't need it.
    return std::make_unique<std::vector<SurakartaPosition>>();
}

std::optional<SurakartaPosition> SurakartaRuleManager::Next(const SurakartaPosition position, const SurakartaDirection direction) {
    const signed int board_size = board_size_; // convert to signed
    const std::pair<int, int> next =
        direction == SurakartaDirection::UP
            ? std::pair(position.x, position.y - 1)
        : direction == SurakartaDirection::DOWN
            ? std::pair(position.x, position.y + 1)
        : direction == SurakartaDirection::LEFT
            ? std::pair(position.x - 1, position.y)
        : direction == SurakartaDirection::RIGHT
            ? std::pair(position.x + 1, position.y)
            : throw new std::logic_error("Invalid direction");
    // Inside:
    if (next.first >= 0 && next.first < board_size && next.second >= 0 && next.second < board_size)
        return SurakartaPosition(next.first, next.second);

    // Upper:
    if (next.first >= 1 && next.first < board_size / 2 && next.second == -1)
        return SurakartaPosition(0, next.first);
    if (next.first >= board_size / 2 && next.first < board_size - 1 && next.second == -1)
        return SurakartaPosition(board_size - 1, board_size - next.first - 1);

    // Lower:
    if (next.first >= 1 && next.first < board_size / 2 && next.second == board_size)
        return SurakartaPosition(0, board_size - next.first - 1);
    if (next.first >= board_size / 2 && next.first < board_size - 1 && next.second == board_size)
        return SurakartaPosition(board_size - 1, next.first);

    // Left:
    if (next.first == -1 && next.second >= 1 && next.second < board_size / 2)
        return SurakartaPosition(next.second, 0);
    if (next.first == -1 && next.second >= board_size / 2 && next.second < board_size - 1)
        return SurakartaPosition(board_size - next.second - 1, board_size - 1);

    // Right:
    if (next.first == board_size && next.second >= 1 && next.second < board_size / 2)
        return SurakartaPosition(board_size - next.second - 1, 0);
    if (next.first == board_size && next.second >= board_size / 2 && next.second < board_size - 1)
        return SurakartaPosition(next.second, board_size - 1);

    // Corner:
    return std::nullopt;
}
